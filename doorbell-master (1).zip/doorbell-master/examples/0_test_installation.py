###################################
# Doorbell with face recognition  #
###################################
#
# Author: Martijn van der Sar
# https://www.github.com/Erientes/

if __name__ == '__main__':
    print('Doorbell installation ended successfully!')